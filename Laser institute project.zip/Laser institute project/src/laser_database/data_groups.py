# -*- coding: utf-8 -*-
"""
Created on Wed Aug 26 11:24:16 2026

@author: remadi
"""
import pandas as pd


def create_logical_groups(df: pd.DataFrame) -> dict[str, pd.DataFrame]:
    entry_table = df[
        [
            "unique ID",
            "experiment_name",
            "Material",
            "laserunite",
            "UserComment",
        ]
    ]

    laser_parameters = df[
        [
            "unique ID",
            "λ [nm]",
            "Pproc/Pout",
            "PL",
            "Pav_out [W]",
            "fB [MHz]",
            "fP [MHz]",
            "nP",
            "tP [ps]",
            "Polarization",
            "Compressor mode",
            "Compr. Pos. [um]",
        ]
    ]

    scanner = df[
        [
            "unique ID",
            "Scanner",
            "f [mm]",
            "w0 [um]",
            "zr [um]",
        ]
    ]

    scan_regime = df[
        [
            "unique ID",
            "Filling method",
            "lproc [mm]",
            "bproc [mm]",
            "v [m/s]",
            "z-z0 [um]",
            "Ldprim [um]",
            "Ldsec [um]",
            "nobject",
            "s [um]",
            "Offset [um]",
        ]
    ]

    return {
        "Entry information": entry_table,
        "Laser parameters": laser_parameters,
        "Scanner parameters": scanner,
        "Scan regime": scan_regime,
    }
