# -*- coding: utf-8 -*-
"""
Created on Wed Aug 26 11:34:24 2026

@author: remadi
"""

import matplotlib.pyplot as plt


def create_scatter_plot(plot_data, x_column, y_column):
    figure, axis = plt.subplots(figsize=(8, 5))

    axis.scatter(
        plot_data[x_column],
        plot_data[y_column],
    )

    axis.set_title(f"{y_column} versus {x_column}")
    axis.set_xlabel(x_column)
    axis.set_ylabel(y_column)
    axis.grid(True)

    figure.tight_layout()

    return figure