# -*- coding: utf-8 -*-
"""
Created on Wed Aug 26 12:59:19 2026

@author: remadi
"""

from pathlib import Path

import matplotlib.pyplot as plt
import streamlit as st

from .background import set_png_as_page_bg
from .config import MAIN_TABLE
from .database import get_table_names, load_table
from .data_groups import create_logical_groups
from .descriptions import descriptions
from .filtering import filter_dataframe
from .numeric_processing import convert_numeric_columns
from .visualization import create_scatter_plot

#Page setup
def setup_page(background_path: Path):
    try:
        set_png_as_page_bg(background_path)
    except (FileNotFoundError, OSError):
        pass

    st.title("Laser Database Search")
    st.caption("Search, filter and visualize laser experiment data.")
    
#Show group data   
def show_logical_groups(df):
    logical_groups = create_logical_groups(df)

    with st.expander("Preview prepared logical data groups"):
        selected_group = st.selectbox(
            "Choose a prepared data group",
            list(logical_groups.keys()),
        )

        st.dataframe(logical_groups[selected_group])
        
#Select Data        
def select_database_table(engine, main_df):
    try:
        tables = get_table_names(engine)
    except Exception as error:
        st.error("Could not read the table names from the database.")
        st.exception(error)
        st.stop()

    if not tables:
        st.warning("No tables were found in the database.")
        st.stop()

    selected_table = st.selectbox(
        "Choose one table",
        tables,
        index=tables.index(MAIN_TABLE) if MAIN_TABLE in tables else 0,
    )

    try:
        if selected_table == MAIN_TABLE:
            selected_df = main_df.copy()
        else:
            selected_df = load_table(engine, selected_table)

    except Exception as error:
        st.error("The selected table could not be loaded.")
        st.exception(error)
        st.stop()

    if selected_df.empty:
        st.warning("The selected table contains no data.")
        st.stop()

    st.write(f"Selected table: **{selected_table}**")
    st.write(f"Rows loaded: **{len(selected_df)}**")
    st.dataframe(selected_df)

    return selected_df


#Show description
def show_descriptions(selected_df):
    available_descriptions = {
        column: description
        for column, description in descriptions.items()
        if column in selected_df.columns
    }

    if not available_descriptions:
        return

    selected_component = st.selectbox(
        "Select a component to see its description",
        list(available_descriptions.keys()),
    )

    st.info(available_descriptions[selected_component])
    
    
#Filter and Chart    
def show_filter_section(selected_df):
    numeric_df, numeric_columns = convert_numeric_columns(selected_df)

    if not numeric_columns:
        st.warning("No numeric columns were found in the selected table.")
        st.stop()

    st.subheader("Filter and visualization")

    filter_column = st.selectbox(
        "Select column for filtering",
        numeric_columns,
    )

    column_min = float(numeric_df[filter_column].min())
    column_max = float(numeric_df[filter_column].max())

    minimum_column, maximum_column = st.columns(2)

    with minimum_column:
        min_value = st.number_input(
            f"Minimum {filter_column}",
            value=column_min,
        )

    with maximum_column:
        max_value = st.number_input(
            f"Maximum {filter_column}",
            value=column_max,
        )

    x_column = st.selectbox(
        "Select X axis",
        numeric_columns,
    )

    y_column = st.selectbox(
        "Select Y axis",
        numeric_columns,
        index=min(1, len(numeric_columns) - 1),
    )

    if not st.button("Search"):
        return

    if min_value > max_value:
        st.error("Minimum value cannot be greater than maximum value.")
        return

    result, plot_data = filter_dataframe(
        selected_df,
        numeric_df,
        filter_column,
        min_value,
        max_value,
        x_column,
        y_column,
    )

    st.write(f"Number of rows: **{len(result)}**")
    st.dataframe(result)

    if result.empty:
        st.warning("No rows match the selected range.")
        return

    if plot_data.empty:
        st.warning(
            "No valid numeric data is available for the selected axes."
        )
        return

    figure = create_scatter_plot(
        plot_data,
        x_column,
        y_column,
    )

    st.pyplot(figure)
    plt.close(figure)