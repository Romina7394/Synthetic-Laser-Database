# -*- coding: utf-8 -*-
"""
Created on Wed Aug 26 11:45:13 2026

@author: remadi
"""

import base64

import streamlit as st


@st.cache_data
def get_base64_of_bin_file(bin_file):
    with open(bin_file, "rb") as file:
        data = file.read()
    return base64.b64encode(data).decode()


def set_png_as_page_bg(png_file):
    bin_str = get_base64_of_bin_file(png_file)

    page_bg_img = f"""
    <style>
    .stApp {{
        position: relative;
        background: black;
    }}

    .stApp::before {{
        content: "";
        position: fixed;
        inset: 0;
        background-image: url("data:image/png;base64,{bin_str}");
        background-size: 30%;
        background-position: center;
        background-repeat: repeat;
        background-attachment: fixed;
        opacity: 0.15;
        z-index: 0;
        pointer-events: none;
    }}

    .stApp > * {{
        position: relative;
        z-index: 1;
    }}
    </style>
    """

    st.markdown(page_bg_img, unsafe_allow_html=True)