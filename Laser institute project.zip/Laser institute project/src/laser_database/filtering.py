# -*- coding: utf-8 -*-
"""
Created on Wed Aug 26 12:49:35 2026

@author: remadi
"""

import pandas as pd


def filter_dataframe(
    selected_df: pd.DataFrame,
    numeric_df: pd.DataFrame,
    filter_column: str,
    min_value: float,
    max_value: float,
    x_column: str,
    y_column: str,
):
    filter_mask = numeric_df[filter_column].between(
        min_value,
        max_value,
        inclusive="both",
    )

    result = selected_df.loc[filter_mask].copy()

    plot_data = numeric_df.loc[
        filter_mask,
        [x_column, y_column],
    ].dropna()

    return result, plot_data