# -*- coding: utf-8 -*-
"""
Created on Wed Aug 26 11:12:43 2026

@author: remadi
"""
import streamlit as st
import pandas as pd
from sqlalchemy import create_engine, inspect

@st.cache_resource
def get_engine():
    username = st.secrets["mysql"]["username"]
    password = st.secrets["mysql"]["password"]
    host = st.secrets["mysql"]["host"]
    database = st.secrets["mysql"]["database"]

    return create_engine(
        f"mysql+pymysql://{username}:{password}@{host}/{database}"
    )
def load_table(engine, table_name):
    return pd.read_sql_query(
        f"SELECT * FROM `{table_name}`;",
        engine,
    )


def get_table_names(engine):
    inspector = inspect(engine)
    return inspector.get_table_names()