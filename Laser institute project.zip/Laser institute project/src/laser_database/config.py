# -*- coding: utf-8 -*-
"""
Created on Wed Aug 26 11:43:34 2026

@author: remadi
"""

MAIN_TABLE = "databank"