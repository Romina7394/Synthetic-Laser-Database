# -*- coding: utf-8 -*-
"""
Created on Wed Aug 26 11:19:07 2026

@author: remadi
"""
import hashlib
import pandas as pd
def prepare_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df = df.rename(
        columns={
            "Area-ID": "experiment_name",
            "Laser": "laserunite",
        }
    )

    df = df.drop(columns=["No"], errors="ignore")

    comment_columns = [
        column
        for column in ["commproc", "commmeas"]
        if column in df.columns
    ]

    if comment_columns:
        df["UserComment"] = (
            df[comment_columns]
            .fillna("")
            .astype(str)
            .agg(", ".join, axis=1)
            .str.strip(", ")
        )
        df = df.drop(columns=comment_columns)


    # Create a stable source hash for each imported row.
    df["unique ID"] = df.apply(
        lambda row: hashlib.sha256(
            "|".join(map(str, row.values)).encode("utf-8")
        ).hexdigest(),
        axis=1,
    )
    return df
