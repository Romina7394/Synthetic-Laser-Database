# -*- coding: utf-8 -*-
"""
Created on Wed Aug 26 11:31:07 2026

@author: remadi
"""

import pandas as pd


def convert_numeric_columns(df: pd.DataFrame):
    numeric_df = df.copy()

    for column in numeric_df.columns:
        cleaned_values = (
            numeric_df[column]
            .astype(str)
            .str.replace(",", ".", regex=False)
            .str.strip()
        )

        converted_values = pd.to_numeric(
            cleaned_values,
            errors="coerce",
        )

        non_empty_values = (
            df[column].notna()
            & df[column].astype(str).str.strip().ne("")
        )

        if (
            non_empty_values.any()
            and converted_values[non_empty_values].notna().mean() >= 0.8
        ):
            numeric_df[column] = converted_values

    numeric_columns = [
        column
        for column in numeric_df.select_dtypes(include="number").columns
        if numeric_df[column].notna().any()
    ]

    return numeric_df, numeric_columns