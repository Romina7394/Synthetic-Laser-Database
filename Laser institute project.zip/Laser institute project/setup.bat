@echo off

echo Creating virtual environment...
python -m venv .venv

echo Activating virtual environment...
call .venv\Scripts\activate

echo Installing dependencies...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo Installing local package...
python -m pip install -e .

echo Installing Spyder kernel support...
python -m pip install "spyder-kernels==3.1.*"

echo.
echo Setup completed successfully.
echo You can now run the application with:
echo python run.py

pause