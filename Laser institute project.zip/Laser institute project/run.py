import os
import subprocess
import sys


def main():
    app_path = os.path.join(
        os.path.dirname(__file__),
        "app.py",
    )

    process = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "streamlit",
            "run",
            app_path,
        ]
    )

    try:
        process.wait()

    except KeyboardInterrupt:
        process.terminate()

        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()


if __name__ == "__main__":
    main()