from pathlib import Path

import streamlit as st

from laser_database.config import MAIN_TABLE
from laser_database.database import get_engine, load_table
from laser_database.data_processing import prepare_dataframe
from laser_database.ui import (
    select_database_table,
    setup_page,
    show_descriptions,
    show_filter_section,
    show_logical_groups,
)


BASE_DIR = Path(__file__).resolve().parent
BACKGROUND_PATH = BASE_DIR / "assets" / "background.png"


def main():
    setup_page(BACKGROUND_PATH)

    try:
        engine = get_engine()
        df = load_table(engine, MAIN_TABLE)
    except Exception as error:
        st.error("Could not connect to the database or load the main table.")
        st.exception(error)
        st.stop()

    df = prepare_dataframe(df)

    show_logical_groups(df)

    selected_df = select_database_table(
        engine,
        df,
    )

    show_descriptions(selected_df)

    show_filter_section(selected_df)


if __name__ == "__main__":
    main()